const prompt = require('prompt-sync')();  

const nombre = prompt('Ingresa tu nombre '); 

console.log(`Hola ${nombre}!`); 
console.log("Hola " + nombre + "!"); 
console.log("Hola",nombre, "!"); 
