const prompt = require('prompt-sync')();   

const numero = parseInt(prompt("Ingrese numero: "));

function cifras (numero){
    if (numero > 0){
        if (numero < 10){
            return "Faltan " + (10 - numero) + " para ser un número de 2 cifras"
        }
        else if (numero < 100){
            return "Faltan " + (100 - numero) + " para ser un número de 3 cifras"
        }
        else {
            return "Ingrese número menor a 2 cifras"
        }
    }
    else{
        return "Ingresa un número válido"
    }
}

console.log(cifras(numero)); 