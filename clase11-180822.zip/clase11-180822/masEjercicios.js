const prompt = require("prompt-sync")({ sigint: true });

/*1) Escribí un programa que le pida al usuario ingresar una frase y
la imprima en la consola. */

/* let frase = prompt("Ingrese frase: ");
console.log(frase) */

/* 2) Escribí un programa que le pregunte al usuario su nombre e
imprima "Hola " seguido del nombre y un signo de
exclamación. */

/* let nombre = prompt("Ingrese nombre: ");
console.log("Hola " + nombre + "!") */

/* 3) Escribí un programa que le pida al usuario ingresar un número,
luego le pida un segundo número, e imprima en la consola la
suma de los dos números que ingresó el usuario. */

/* let a = Number(prompt("Ingrese un número: "));
let b = Number(prompt("Ingrese otro número: "));
console.log(a+b) */

/* 4) Escribí un programa que le pida al usuario su año de
nacimiento e imprima su edad actual en la consola con la frase
"Tienes X años" (siendo X la cantidad de años). */

/* let anio = Number(prompt("Ingrese su año de nacimiento: "));
console.log("Tienes " + (2022-anio) + " años") */

/* 5) Escribí un programa que piense un número de forma aleatoria
del 1 al 10 y le pida al usuario que lo trate de adivinar. Si el
número es correcto debe imprimir en la consola "Felicitaciones,
ese era!", de lo contrario, debe imprimir "Lo siento, intenta
nuevamente!" */

/* var random_number = Math.floor(Math.random() * 10);
console.log(random_number); */

/* 6) Escribí un programa que imprima los números pares del 0 al
100. */

/* let i = 0;
for (i = 0; i <= 100; i++){
    if (i % 2 == 0){
        console.log(i)
    }
} */

/* 7) Escribí un programa que itere sobre el arreglo nombres e
imprima cada uno en la consola: const nombres = ["Pedro",
"Pablo", "Maria", "Juan", "Diana"]; */

/* let nameArray = ["Pedro","Pablo", "Maria", "Juan", "Diana"]

for (let index = 0; index < nameArray.length; index++) {
    console.log(nameArray[index])
} */

/* 8) Construí un pseudocódigo que permita ingresar un número, si
el número es mayor de 500, se debe calcular y mostrar en
pantalla el 18% de este. */

/* let numero = parseInt(prompt("Ingrese numero: "));

if (numero > 500){
    console.log(numero * 0.18)
} */

/* 9) Escribí una función llamada elemento que recibe un arreglo
como parámetro. La función debe devolver el valor que se
encuentra en la tercera posición. Si el arreglo no tiene al menos
3 elementos deberá retornar -1. */

/* let array = ["Pedro","Pablo", "Maria", "Juan", "Diana"]

function elemento (array){
    if(array.length >= 3){
        return array[2]
    } 
    else {
        return (array[array.length -1])
    }
}

console.log(elemento(array)) */

/* 10) Se ingresa por teclado un número natural de hasta 2 cifras, si
tiene una cifra que muestre lo mínimo que le falta para ser un
número de 2 cifras; de lo contrario, que muestre lo mínimo que
le falta para ser un número de 3 cifras. Considerar que el
usuario ingresa números de hasta dos cifras. */
/* 
let numero = parseInt(prompt("Ingrese numero: "));

function cifras (numero){
    if (numero > 0){
        if (numero < 10){
            return "Faltan " + (10 - numero) + " para ser un número de 2 cifras"
        }
        else if (numero < 100){
            return "Faltan " + (100 - numero) + " para ser un número de 3 cifras"
        }
        else {
            return "Ingrese número menor a 2 cifras"
        }
    }
    else{
        return "Ingresa un número válido"
    }
}

console.log(cifras(numero)); */

/* 11) Hacer un algoritmo que muestre el promedio de varias
notas o de N notas ingresadas, se debe definir el valor de N
para conocer la cantidad de notas a ingresar. */

/* (function calculandoPromedio() {
    const respuestaCliente = parseInt(prompt('Ingrese la cantidad de notas que desea promediar: ')); 

    if(respuestaCliente < 0  || respuestaCliente > 10) { 
        return 'Ingrese notas validas la proxima vez ;)'; 
    } else {
        let totalDeNotas = 0; 

        for (let index = 0; index < respuestaCliente; index++) {
            let nota = parseInt(prompt('Ingresa una nota entre 1 y 10 incluidos: '));
            while(nota < 0  || nota > 10) {
                nota = parseInt(prompt('Ingreso una nota invalida, vuelva a intentarlo: '));
            }
            totalDeNotas = totalDeNotas + nota;
        }
        console.log('El promedio es ', totalDeNotas/respuestaCliente);
    }

})(); */

/* 12) Hacer un programa que calcule la suma de los N primeros
números naturales, dónde N es el número límite ingresado por
teclado. */

const numero = parseInt(prompt('Ingrese un número natural: ')); 

(function numeroNatural (numero){
    if (numero < 0){
        return "Intenta de nuevo"
    } 
    else {
        let acumulador = 0
        for (let index = 0; index <= numero; index++) {
            acumulador = acumulador + (numero - index);
        }
        console.log("La suma de los números naturales es: " + acumulador);
    }
})(numero)
