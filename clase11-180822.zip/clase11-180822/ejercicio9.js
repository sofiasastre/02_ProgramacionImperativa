const prompt = require('prompt-sync')();    

const numero = parseInt(prompt('Ingrese un número natural: ')); 

(function numeroNatural (numero){
    if (numero < 0){
        return "Intenta de nuevo"
    } 
    else {
        let acumulador = 0
        for (let index = 0; index <= numero; index++) {
            acumulador = acumulador + (numero - index);
        }
        console.log("La suma de los números naturales es: " + acumulador);
    }
})(numero)