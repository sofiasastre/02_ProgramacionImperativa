const prompt = require('prompt-sync')(); 

console.log(prompt('Ingresa una frase '));