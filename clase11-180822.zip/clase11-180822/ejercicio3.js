const prompt = require('prompt-sync')();  

const n1 = parseInt(prompt('Ingresa un numero: '));
const n2 = parseInt(prompt('Ingresa otro numero: '));

console.log(n1 + n2);