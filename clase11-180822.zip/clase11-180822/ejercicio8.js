const prompt = require('prompt-sync')();   

(function calculandoPromedio() {
    const respuestaCliente = parseInt(prompt('Ingrese la cantidad de notas que desea promediar: ')); 

    if(respuestaCliente < 0) { 
        return 'Ingrese una cantidad positiva'; 
    } else {
        let totalDeNotas = 0; 

        for (let index = 0; index < respuestaCliente; index++) {
            let nota = parseInt(prompt('Ingresa una nota entre 1 y 10 incluidos: '));
            while(nota < 0  || nota > 10) {
                nota = parseInt(prompt('Ingreso una nota invalida, vuelva a intentarlo: '));
            }
            totalDeNotas = totalDeNotas + nota;
        }
        console.log('El promedio es ', totalDeNotas/respuestaCliente);
    }

})();