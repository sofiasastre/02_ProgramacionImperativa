const prompt = require('prompt-sync')();  

const anioNacimiento = parseInt(prompt('Ingresa tu anio de nacimiento: '));

console.log(`Tienes ${2022-anioNacimiento} anios`);