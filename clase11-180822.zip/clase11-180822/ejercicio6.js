for (let index = 0; index <= 100; index++) {
    if(index % 2 === 0){
        console.log(index);
    }
}